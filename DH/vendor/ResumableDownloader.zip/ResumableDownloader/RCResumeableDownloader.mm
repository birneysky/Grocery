//
//  RCEResumeableDownloader.m
//  RongEnterpriseApp
//
//  Created by zhaobingdong on 2018/5/15.
//  Copyright © 2018年 rongcloud. All rights reserved.
//

#import "RCResumeableDownloader.h"
#import "RCIMClient.h"
#import "RCFileMessage.h"
#import "RCImageMessage.h"
#import "RCloudBiz.h"

NSString* const storagePath = @"Documents/MyFile";

@interface RCIMClient ()
- (NSString *)payloadOfMessageContent:(RCMessageContent *)content ;
@end;

@interface RCDownloadItem ()
@property (nonatomic,weak) NSURLSessionDataTask *dataTask;
@property (nonatomic,strong) NSOutputStream *outputStream;
@property (nonatomic,assign) long long totalLength;
@property (nonatomic,assign) RCDownloadItemState state;
@property (nonatomic,assign) long long  currentLength;
@property (nonatomic,assign,) BOOL resumable;
@property (nonatomic,copy) NSString* localPath;
@end

@interface RCResumeableDownloader () <NSURLSessionDelegate>
@property (nonatomic, strong) NSURLSession *urlSession;
@property (nonatomic, strong) NSMutableDictionary<NSString*,RCDownloadItem*>* items;
//@property (nonatomic, copy) NSString* downloadPath;
@property (nonatomic, copy) NSString* archivePath;
@property (nonatomic, copy) NSString* archiveFileFullPath;
@end

@implementation RCResumeableDownloader
#pragma mark - Properties
- (NSURLSession *)urlSession {
    
    if (!_urlSession) {
        _urlSession = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]
                                                    delegate:self
                                               delegateQueue:[[NSOperationQueue alloc] init]];
    }
    return _urlSession;
}

//- (NSString*)downloadPath {
//    if (!_downloadPath) {
//        NSString* cachePath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).lastObject;
//        _downloadPath =[cachePath stringByAppendingPathComponent:NSStringFromClass([self class])];
//    }
//    return _downloadPath;
//}



- (NSString*)archivePath {
    if (!_archivePath) {
        NSString* cachePath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).lastObject;
        _archivePath =[cachePath stringByAppendingPathComponent:NSStringFromClass([self class])];
    }
    return _archivePath;
}

- (NSString*)archiveFileFullPath {
    if (!_archiveFileFullPath) {
        _archiveFileFullPath = [self.archivePath stringByAppendingPathComponent:@"DownloadItems.archive"];
    }
    return _archiveFileFullPath;
}

- (NSMutableDictionary<NSString*,RCDownloadItem*>*)items {
    if (!_items) {
        _items = [[NSMutableDictionary alloc] initWithCapacity:10];
    }
    return _items;
}

+ (NSString*)taskIdentify:(NSURL*)url {
    NSUInteger hash = [url hash];
    return [NSString stringWithFormat:@"%lld",(long long)hash];
}

+ (NSString*)fileNameOfURL:(NSURL*)url targetDirectory:(NSString*)target{
    NSString* component = [[url lastPathComponent] stringByRemovingPercentEncoding];
    NSString* fileName = [component stringByDeletingPathExtension];
    NSString* extionName = [component pathExtension];
//    NSRange range = [component rangeOfComposedCharacterSequencesForRange:NSMakeRange(0, 6)];
//    NSString* head = [component substringWithRange:range];
 
    NSString* filePath = [target stringByAppendingPathComponent:component];
    long i = 1;
    while ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        component = [fileName stringByAppendingFormat:@"%@(%ld).%@",fileName,i,extionName];
        filePath = [target stringByAppendingPathComponent:component];
        ++i;
    }
    
    if (component.length > 255) {
        component = [component substringFromIndex:component.length-255];
    }
    
    return component;
}

+ (NSString*)fileNameOfURL:(NSURL*)url {
    NSString* component = [[url lastPathComponent] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    if (component.length > 255) {
        component = [component substringFromIndex:component.length-255];
    }
    return component;
}

- (NSString*)fileFullPathOfURL:(NSURL*)url {
    NSString* fileName = [RCResumeableDownloader pathOfURL:url];
    return [NSHomeDirectory() stringByAppendingPathComponent:fileName];
}
///
+ (NSString*)pathOfURL:(NSURL*)url {
  //  NSString* targetDir = [NSHomeDirectory() stringByAppendingPathComponent:@"tmp"];
     NSString* fileName = [RCResumeableDownloader fileNameOfURL:url];
    return [@"tmp" stringByAppendingPathComponent:fileName];
}

- (NSUInteger)downloadedLength:(NSURL*)url {
    NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:[self fileFullPathOfURL:url] error:nil];
    if (!fileAttributes) {
        return 0;
    }
    return [fileAttributes[NSFileSize] integerValue];
}

#pragma mark - Api
+ (instancetype)defaultInstance {
    static RCResumeableDownloader *downloader;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        downloader = [[[self class] alloc] init];
        NSDictionary* items = [NSKeyedUnarchiver unarchiveObjectWithFile:[downloader archiveFileFullPath]];
        [downloader.items addEntriesFromDictionary:items];
        [[NSNotificationCenter defaultCenter] addObserver:downloader selector:@selector(archiveItems) name:UIApplicationWillTerminateNotification object:nil];
    });
    return downloader;
}

- (void)downLoad:(RCDownloadItem*)item {

    [self createDirectoryIfNeed];
    NSURL* url = item.URL;
    
    NSString* targetFileName =  [RCResumeableDownloader taskIdentify:url];
//    if (self.items[targetFileName]) {
//        return;
//    } else {
        [self.items setObject:item forKey:targetFileName];
//    }
    
    NSURLSessionDataTask* task = [self headTask:url];
//    if (item.state == RCDownloadItemStateRunning) {
//        return;
//    }
    [task resume];
    [item.delegate downloadItem:item state:RCDownloadItemStateChecking];
     [self archiveItems];
}

- (void)suspend:(RCDownloadItem*)item {
     NSURL* url = item.URL;
    NSURLSessionDataTask* task = [self downloadTask:url];
    [task suspend];
    item.state = RCDownloadItemStateSuspended;
    [item.delegate downloadItem:item state:RCDownloadItemStateSuspended];
     [self archiveItems];
}

- (void)resume:(RCDownloadItem*)item {
    NSURL* url = item.URL;
    NSURLSessionDataTask* task = [self downloadTask:url];
    [task resume];
    item.state = RCDownloadItemStateRunning;
    [item.delegate downloadItem:item state:RCDownloadItemStateRunning];
     [self archiveItems];
}

- (void)cancel:(RCDownloadItem*)item {
     NSURL* url = item.URL;
    NSURLSessionDataTask* task = [self downloadTask:url];
    [task cancel];
    item.state = RCDownloadItemStateCanceled;
    [item.delegate downloadItem:item state:RCDownloadItemStateCanceled];
     [self archiveItems];
}

- (RCDownloadItem*)itemOf:(NSURL*)url {
    NSString* targetFileName =  [RCResumeableDownloader taskIdentify:url];
    RCDownloadItem* item = self.items[targetFileName];
    return item;
}




#pragma mark - Helpers
- (NSURLSessionDataTask*)downloadTask:(NSURL*)url {
    NSString* targetFileName =  [RCResumeableDownloader taskIdentify:url];
    RCDownloadItem* item = self.items[targetFileName];
    if (!item) {
        return nil;
    }
    if (!item.dataTask) {
        NSMutableURLRequest *requestM = [NSMutableURLRequest requestWithURL:url];
        NSString* rangeValue = [NSString stringWithFormat:@"bytes=%ld-", (long)[self downloadedLength:url]];
        [requestM setValue:rangeValue forHTTPHeaderField:@"Range"];
        NSURLSessionDataTask *dataTask = [self.urlSession dataTaskWithRequest:requestM];
        dataTask.taskDescription = targetFileName;
        NSOutputStream* output = [NSOutputStream outputStreamToFileAtPath:[self fileFullPathOfURL:url] append:YES];
        item.outputStream = output;
        item.dataTask = dataTask;
        return dataTask;
    } else {
        return item.dataTask;
    }

}

- (NSURLSessionDataTask*)newDownloadTask:(NSURL*)url {
    NSString* targetFileName =  [RCResumeableDownloader taskIdentify:url];
    RCDownloadItem* item = self.items[targetFileName];
    if (!item) {
        return nil;
    }
    NSMutableURLRequest *requestM = [NSMutableURLRequest requestWithURL:url];
    NSString* rangeValue = [NSString stringWithFormat:@"bytes=%ld-", (long)[self downloadedLength:url]];
    if (item.resumable) {
        [requestM setValue:rangeValue forHTTPHeaderField:@"Range"];
    }
    NSURLSessionDataTask *dataTask = [self.urlSession dataTaskWithRequest:requestM];
    dataTask.taskDescription = targetFileName;
    NSString* path = [RCResumeableDownloader pathOfURL:url];
    NSString* fullPath = [NSHomeDirectory() stringByAppendingPathComponent:path];
    NSOutputStream* output = [NSOutputStream outputStreamToFileAtPath:fullPath append:YES];
    item.outputStream = output;
    item.dataTask = dataTask;
    return dataTask;
}

- (NSURLSessionDataTask*)headTask:(NSURL*)url {
    NSString* targetFileName =  [RCResumeableDownloader taskIdentify:url];
    RCDownloadItem* item = self.items[targetFileName];
    if (!item) {
        return nil;
    }
    NSMutableURLRequest *requestM = [NSMutableURLRequest requestWithURL:url];
    requestM.HTTPMethod = @"HEAD";
    NSURLSessionDataTask *dataTask = [self.urlSession dataTaskWithRequest:requestM];
    dataTask.taskDescription = targetFileName;
    item.dataTask = dataTask;
    return dataTask;
}

- (void)createDirectoryIfNeed {
    BOOL isDirectory = NO;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isExists = [fileManager fileExistsAtPath:self.archivePath isDirectory:&isDirectory];
    if (!isExists || !isDirectory) {
        [fileManager createDirectoryAtPath:self.archivePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSString* myFilePath = [NSHomeDirectory() stringByAppendingPathComponent:storagePath];
    if (![fileManager fileExistsAtPath:myFilePath]) {
        [fileManager createDirectoryAtPath:myFilePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
}

- (void)archiveItems {
    [NSKeyedArchiver archiveRootObject:self.items toFile:self.archiveFileFullPath];
}


#pragma mark - NSURLSessionDataDelegate
- (void)URLSession:(NSURLSession *)session
          dataTask:(NSURLSessionDataTask *)dataTask
didReceiveResponse:(NSHTTPURLResponse *)response
 completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler {
    RCDownloadItem *item = self.items[dataTask.taskDescription];
    if (!item) {
        completionHandler(NSURLSessionResponseCancel);
        return;
    }
    if ([dataTask.currentRequest.HTTPMethod isEqualToString:@"HEAD"]) {
        if ([response.allHeaderFields objectForKey:@"Accept-Ranges"]) {
            item.resumable = YES;
        } else {
            item.resumable = NO;
            NSString* relativeLocalPath = [RCResumeableDownloader pathOfURL:item.URL];
            NSString* srcPath = [NSHomeDirectory() stringByAppendingPathComponent:relativeLocalPath];
            [[NSFileManager defaultManager] removeItemAtPath:srcPath error:nil];
            
        }
        completionHandler(NSURLSessionResponseAllow);
        return;
    }
    [item.outputStream open];
    long long thisTotalLength = response.expectedContentLength; // Equals to [response.allHeaderFields[@"Content-Length"] integerValue]
    long long totalLength = thisTotalLength + [self downloadedLength:item.URL];
    item.totalLength = totalLength;
    dispatch_async(dispatch_get_main_queue(), ^{
        item.state = RCDownloadItemStateRunning;
        [item.delegate downloadItem:item state:RCDownloadItemStateRunning];
    });
    [self archiveItems];
    completionHandler(NSURLSessionResponseAllow);
}

- (void)URLSession:(NSURLSession *)session
          dataTask:(NSURLSessionDataTask *)dataTask
    didReceiveData:(NSData *)data {
    RCDownloadItem *item = self.items[dataTask.taskDescription];
    if (!item) {
        return;
    }
    
    [item.outputStream write:(const uint8_t *)data.bytes maxLength:data.length];
    dispatch_async(dispatch_get_main_queue(), ^{
        long long  receivedSize = [self downloadedLength:item.URL];
        long long  expectedSize = item.totalLength;
        item.currentLength = receivedSize;
        float progress = 1.0 * receivedSize / expectedSize;
        [item.delegate downloadItem:item progress:progress];
    });
}

- (void)URLSession:(NSURLSession *)session
              task:(NSURLSessionTask *)task
didCompleteWithError:(NSError *)error {
    RCDownloadItem *item = self.items[task.taskDescription];
    if (!item) {
        return;
    }

    if ([task.currentRequest.HTTPMethod isEqualToString:@"HEAD"]) {
        NSURL* url = task.currentRequest.URL;
        NSURLSessionDataTask *dataTask1 = [self newDownloadTask:url];
        [dataTask1 resume];
        [self archiveItems];
        return;
    }
    
   
    NSString* relativeLocalPath = [RCResumeableDownloader pathOfURL:item.URL];
    NSString* targetDir = [NSHomeDirectory() stringByAppendingPathComponent:storagePath];
    NSString* storageFileName = [RCResumeableDownloader fileNameOfURL:item.URL targetDirectory:targetDir];
    NSString* relativeStoragePath = [storagePath stringByAppendingPathComponent:storageFileName];
    NSString* srcPath = [NSHomeDirectory() stringByAppendingPathComponent:relativeLocalPath];
    if (!error && [self downloadedLength:item.URL] == item.totalLength) {
        [self.items removeObjectForKey:task.taskDescription];
        [item.outputStream close];
        NSString* dstPath = [NSHomeDirectory() stringByAppendingPathComponent:relativeStoragePath];
        [[NSFileManager defaultManager] moveItemAtPath:srcPath toPath:dstPath error:nil];
        if (item.messageId > 0) {
            updateMessageContent(item.messageId, relativeStoragePath);
        }
    } else {
        if (!error) {
            error = [NSError errorWithDomain:NSOSStatusErrorDomain code:-1 userInfo:@{NSLocalizedFailureReasonErrorKey:@"Incomplete documents"}];
        }
        relativeStoragePath = nil;
        item.state = RCDownloadItemStateFailed;
        if (!item.resumable) {
            [[NSFileManager defaultManager] removeItemAtPath:srcPath error:nil];
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [item.delegate downloadItem:item
               didCompleteWithError:error
                           filePath:relativeStoragePath];
    });
//    NSLog(@"🤬🤬🤬🤬🤬🤬🤬🤬🤬🤬 didCompleteWithError %@ %@",error,item.URL);
    [self archiveItems];
}

void updateMessageContent(long messageId,NSString* localPath) {
    RCMessage* message = [[RCIMClient sharedRCIMClient] getMessage:messageId];
    if (!message) {
        return;
    }
    if ([message.content isKindOfClass:[RCFileMessage class]]) {
        RCFileMessage* fileMessage = (RCFileMessage*)message.content;
        fileMessage.localPath = localPath;
        NSString *dataString = [[RCIMClient sharedRCIMClient] payloadOfMessageContent:fileMessage];
        RongCloud::SetMessageContent(messageId, [dataString UTF8String]);
    } else if ([message.content isKindOfClass:[RCImageMessage class]]) {
        RCImageMessage* imageMessage = (RCImageMessage*)message.content;
        imageMessage.localPath = localPath;
        NSString *dataString = [[RCIMClient sharedRCIMClient] payloadOfMessageContent:imageMessage];
        RongCloud::SetMessageContent(messageId, [dataString UTF8String]);
    } else {
        NSLog(@"No support message type %@",NSStringFromClass(message.content.class));
    }
}


@end
