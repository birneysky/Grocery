//
//  RCEDownloadItem.m
//  RongEnterpriseApp
//
//  Created by zhaobingdong on 2018/5/15.
//  Copyright © 2018年 rongcloud. All rights reserved.
//

#import "RCDownloadItem.h"
#import "RCIMClient.h"
#import "RCFileMessage.h"
#import "RCImageMessage.h"

@interface RCDownloadItem ()
@property (nonatomic,weak) NSURLSessionDataTask *dataTask;
@property (nonatomic,strong) NSOutputStream *outputStream;
@property (nonatomic,assign) long long totalLength;
@property (nonatomic,assign) long long currentLength;
@property (nonatomic,strong) NSURL *URL;
@property (nonatomic,assign) long messageId;
@property (nonatomic,assign) RCDownloadItemState state;
@property (nonatomic,assign) BOOL resumable;
@property (nonatomic,copy) NSString* localPath;
@end

NSNotificationName RCDownloadItemStateChangedNotification = @"RCDownloadItemStateChangedNotification";

@implementation RCDownloadItem

-(instancetype)initWithURL:(NSURL*)url {
    if (self = [super init]) {
        self.URL = url;
        self.resumable = YES;
    }
    return self;
}

- (instancetype) initWithMessageId:(long)msgId {
    RCMessage* message = [[RCIMClient sharedRCIMClient] getMessage:msgId];
    NSAssert(message, @"Error, no message for messageId: %zd.",msgId);
    NSString* strUrl = nil;
    if ([message.content isKindOfClass:[RCFileMessage class]]) {
        RCFileMessage* fileMessage = (RCFileMessage*)message.content;
        strUrl = fileMessage.fileUrl;
    } else if ([message.content isKindOfClass:[RCImageMessage class]]) {
        RCImageMessage* imageMessage = (RCImageMessage*)message.content;
        strUrl = imageMessage.imageUrl;
    } else {
        NSAssert(NO, @"No support message type %@",NSStringFromClass(message.content.class));
    }
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL* url = [NSURL URLWithString:strUrl];
    if (self = [super init]) {
        self.URL = url;
        self.messageId = msgId;
        self.resumable = YES;
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        self.URL = [aDecoder decodeObjectForKey:@"URL"];
        self.messageId = [[aDecoder decodeObjectForKey:@"messageId"] longValue];
        self.state = [[aDecoder decodeObjectForKey:@"state"] integerValue];
        self.totalLength = [[aDecoder decodeObjectForKey:@"totalLength"] integerValue];
        self.currentLength = [[aDecoder decodeObjectForKey:@"currentLength"] integerValue];
        self.resumable = [[aDecoder decodeObjectForKey:@"resumable"] boolValue];
        if (self.state == RCDownloadItemStateRunning) {
            self.state = self.resumable ? RCDownloadItemStateSuspended : RCDownloadItemStateFailed;
        }
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.URL forKey:@"URL"];
    [aCoder encodeObject:@(self.messageId) forKey:@"messageId"];
    [aCoder encodeObject:@(self.state) forKey:@"state"];
    [aCoder encodeObject:@(self.totalLength) forKey:@"totalLength"];
    [aCoder encodeObject:@(self.currentLength) forKey:@"currentLength"];
    [aCoder encodeObject:@(self.resumable) forKey:@"resumable"];
}



- (void)downLoad {
    [self.dataTask resume];
    [self.delegate downloadItem:self state:RCDownloadItemStateChecking];
    [[NSNotificationCenter defaultCenter] postNotificationName:RCDownloadItemStateChangedNotification object:nil];
}

- (void)suspend {
    [self.dataTask suspend];
    [self.delegate downloadItem:self state:RCDownloadItemStateSuspended];
    [[NSNotificationCenter defaultCenter] postNotificationName:RCDownloadItemStateChangedNotification object:nil];
}

- (void)resume {
    [self.dataTask resume];
    [self.delegate downloadItem:self state:RCDownloadItemStateRunning];
    [[NSNotificationCenter defaultCenter] postNotificationName:RCDownloadItemStateChangedNotification object:nil];
}

- (void)cancel {
    [self.dataTask cancel];
    [self.delegate downloadItem:self state:RCDownloadItemStateCanceled];
    [[NSNotificationCenter defaultCenter] postNotificationName:RCDownloadItemStateChangedNotification object:nil];
}

@end
