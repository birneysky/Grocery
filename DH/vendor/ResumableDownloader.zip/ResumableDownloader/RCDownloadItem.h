//
//  RCEDownloadItem.h
//  RongEnterpriseApp
//
//  Created by zhaobingdong on 2018/5/15.
//  Copyright © 2018年 rongcloud. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 下载状态枚举

 - RCEDownloadItemStateWaiting: 等待
 - RCDownloadItemStateChecking: 正在检测是否支持 Range
 - RCEDownloadItemStateRunning: 正在下载
 - RCEDownloadItemStateSuspended: 暂停
 - RCEDownloadItemStateCanceled: 已取消
 - RCEDownloadItemStateCompleted: 完成
 - RCEDownloadItemStateFailed: 失败
 */
typedef NS_ENUM(NSInteger, RCDownloadItemState) {
    RCDownloadItemStateWaiting = 0,
    RCDownloadItemStateChecking,
    RCDownloadItemStateRunning,
    RCDownloadItemStateSuspended,
    RCDownloadItemStateCanceled,
    RCDownloadItemStateCompleted,
    RCDownloadItemStateFailed
};

@class RCDownloadItem;
@protocol RCDownloadItemDelegate <NSObject>
- (void)downloadItem:(RCDownloadItem*)item state:(RCDownloadItemState)state;
- (void)downloadItem:(RCDownloadItem*)item progress:(float)progress;
- (void)downloadItem:(RCDownloadItem*)item didCompleteWithError:(NSError*)error filePath:(NSString*)path;
@end


@interface RCDownloadItem : NSObject

-(instancetype)initWithURL:(NSURL*)url;
-(instancetype)initWithMessageId:(long)msgId;

//@property (nonatomic,weak,readonly) NSURLSessionDataTask *dataTask;
@property (nonatomic,assign,readonly) RCDownloadItemState state;
//@property (nonatomic,strong,readonly) NSOutputStream *outputStream;
@property (nonatomic,assign,readonly) long long totalLength;
@property (nonatomic,assign,readonly) long long currentLength;
@property (nonatomic,strong,readonly) NSURL *URL;
@property (nonatomic,assign,readonly) BOOL resumable;
@property (nonatomic,weak) id<RCDownloadItemDelegate> delegate;
@property (nonatomic,assign,readonly) long messageId;
@property (nonatomic,copy,readonly) NSString* localPath;


/**
 开始下载
 */
- (void)downLoad;

/**
 暂停下载
 */
- (void)suspend;

/**
 恢复下载
 */
- (void)resume;


/**
 取消下载
 */
- (void)cancel;

@end

