//
//  RCEResumeableDownloader.h
//  RongEnterpriseApp
//
//  Created by zhaobingdong on 2018/5/15.
//  Copyright © 2018年 rongcloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCDownloadItem.h"

@interface RCResumeableDownloader : NSObject

+ (instancetype)defaultInstance;


/**
 下载某一个item

 @param item 待下载item的信息
 @dicussion 如果
 */
- (void)downLoad:(RCDownloadItem*)item;


/**
 暂停某一项下载

 @param item 下载项的信息
 */
- (void)suspend:(RCDownloadItem*)item;


/**
 恢复某一项下载

 @param item 下载项的信息
 */
- (void)resume:(RCDownloadItem*)item;


/**
 取消某一项下载

 @param item 下载项的信息
 */
- (void)cancel:(RCDownloadItem*)item;



- (RCDownloadItem*)itemOf:(NSURL*)url;

- (RCDownloadItem*)itemWithURL:(NSURL*)url;

- (RCDownloadItem*)itemWithMessageId:(long long)msgId;



@end
