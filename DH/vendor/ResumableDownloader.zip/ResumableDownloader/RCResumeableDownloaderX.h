//
//  RCEResumeableDownloader.h
//  RongEnterpriseApp
//
//  Created by zhaobingdong on 2018/5/15.
//  Copyright © 2018年 rongcloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCDownloadItem.h"

@interface RCResumeableDownloaderX : NSObject

+ (instancetype)defaultInstance;






@end
